# component.netcore.apiclient.seg.Model.GenericError
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UniqueErrorId** | **string** |  | [optional] 
**ErrorCode** | **string** |  | [optional] 
**Message** | **string** |  | [optional] 
**MessageType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


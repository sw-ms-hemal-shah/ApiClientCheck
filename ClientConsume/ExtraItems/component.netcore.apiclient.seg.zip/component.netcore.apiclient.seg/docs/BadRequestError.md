# component.netcore.apiclient.seg.Model.BadRequestError
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ErrorCode** | **string** |  | [optional] 
**Message** | **List&lt;string&gt;** |  | [optional] 
**MessageType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


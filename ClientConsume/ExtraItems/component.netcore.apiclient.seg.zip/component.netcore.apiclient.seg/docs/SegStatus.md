# component.netcore.apiclient.seg.Model.SegStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UpdateStatus** | **string** | Allow valid Enum value. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


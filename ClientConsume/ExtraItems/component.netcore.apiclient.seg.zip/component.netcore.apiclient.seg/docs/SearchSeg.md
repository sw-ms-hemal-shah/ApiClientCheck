# component.netcore.apiclient.seg.Model.SearchSeg
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Status** | **string** | Allow valid Enum value. | [optional] 
**Keyword** | **string** |  | [optional] 
**GroupId** | **Guid?** |  | [optional] 
**EligibilityClass** | **string** | Allow valid Enum value. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


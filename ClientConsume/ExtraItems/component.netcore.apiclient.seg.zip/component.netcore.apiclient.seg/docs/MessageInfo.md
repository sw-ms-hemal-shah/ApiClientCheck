# component.netcore.apiclient.seg.Model.MessageInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MessageCode** | **string** |  | [optional] 
**Message** | **string** |  | [optional] 
**MessageType** | **string** |  | [optional] 
**MessageParams** | **Dictionary&lt;string, string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


# component.netcore.apiclient.seg.Model.ResponseInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ResponseId** | **string** |  | [optional] 
**AdditionalValues** | [**List&lt;KeyValuePairStringString&gt;**](KeyValuePairStringString.md) |  | [optional] 
**Messages** | [**List&lt;MessageInfo&gt;**](MessageInfo.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

